package com.isi.java.tictac;

public class InputFields  extends Computer
{
  public void setText()
  {

  }
	
}
