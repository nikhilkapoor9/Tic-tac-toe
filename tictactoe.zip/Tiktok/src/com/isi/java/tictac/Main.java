package com.isi.java.tictac;

public class Main 
{
	public static void main(String args[])

	{	
		
	
		Tictac tt=new Tictac();
		// Wingame win=new Wingame();

	//	Computer computer = new Computer();
	}



}
