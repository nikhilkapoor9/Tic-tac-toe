package com.isi.java.tictac;

public class DataI {

	private int value =0;
	
	public int getvalue()

	{
		return value;
	}
	
	
	public int increment()

	{
		
		return ++value;
	}
}
