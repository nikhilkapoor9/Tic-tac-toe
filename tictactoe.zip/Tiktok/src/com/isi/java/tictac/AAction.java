package com.isi.java.tictac;

import javax.swing.JButton;

public class AAction  {

public void 	display()
	{
		
//	buttonr11.setName("x");;
	}
	
	
	
}
